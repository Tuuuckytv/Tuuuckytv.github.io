using System.Text.Json;

namespace WordWatcher;

internal sealed class WordWatcherSettings
{
    public List<string> WatchTerms { get; set; } = new();
    public bool MonitoringEnabled { get; set; } = true;
}

internal sealed class SettingsStore
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    private readonly string _portablePath = Path.Combine(AppContext.BaseDirectory, "WordWatcher.settings.json");
    private readonly string _fallbackPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "WordWatcher",
        "WordWatcher.settings.json");

    public string CurrentPath { get; private set; }

    public SettingsStore()
    {
        CurrentPath = File.Exists(_portablePath) ? _portablePath : _fallbackPath;
    }

    public WordWatcherSettings Load()
    {
        foreach (var path in new[] { _portablePath, _fallbackPath })
        {
            if (!File.Exists(path)) continue;

            try
            {
                var json = File.ReadAllText(path);
                var settings = JsonSerializer.Deserialize<WordWatcherSettings>(json, JsonOptions);
                if (settings is null) continue;

                settings.WatchTerms = NormaliseTerms(settings.WatchTerms);
                CurrentPath = path;
                return settings;
            }
            catch
            {
                // A bad local settings file should not stop the utility from starting.
            }
        }

        CurrentPath = _portablePath;
        return new WordWatcherSettings();
    }

    public void Save(WordWatcherSettings settings)
    {
        settings.WatchTerms = NormaliseTerms(settings.WatchTerms);
        var json = JsonSerializer.Serialize(settings, JsonOptions);

        try
        {
            WriteFile(_portablePath, json);
            CurrentPath = _portablePath;
            return;
        }
        catch (UnauthorizedAccessException) { }
        catch (IOException) { }

        WriteFile(_fallbackPath, json);
        CurrentPath = _fallbackPath;
    }

    private static void WriteFile(string path, string content)
    {
        var directory = Path.GetDirectoryName(path);
        if (!string.IsNullOrWhiteSpace(directory)) Directory.CreateDirectory(directory);
        File.WriteAllText(path, content);
    }

    public static List<string> NormaliseTerms(IEnumerable<string>? terms)
    {
        return (terms ?? Enumerable.Empty<string>())
            .Select(term => term.Trim())
            .Where(term => term.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }
}
