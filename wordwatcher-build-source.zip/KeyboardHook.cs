using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace WordWatcher;

internal sealed class KeyboardHook : IDisposable
{
    private const int WhKeyboardLl = 13;
    private const int WmKeyDown = 0x0100;
    private const int WmSysKeyDown = 0x0104;
    private const int VkF3 = 0x72;
    private const int VkControl = 0x11;
    private const int VkMenu = 0x12;
    private const int VkLWin = 0x5B;
    private const int VkRWin = 0x5C;
    private const int VkC = 0x43;
    private const int VkV = 0x56;
    private const int VkBack = 0x08;

    private readonly LowLevelKeyboardProc _proc;
    private IntPtr _hookId;
    private DateTime _lastF3At = DateTime.MinValue;

    public event Action? F3Pressed;
    public event Action? BackspacePressed;
    public event Action? CopyGesture;
    public event Action? PasteGesture;
    public event Action<char>? CharacterTyped;

    public KeyboardHook()
    {
        _proc = HookCallback;
        _hookId = SetHook(_proc);
        if (_hookId == IntPtr.Zero)
            throw new InvalidOperationException("Windows could not install the Word Watcher keyboard hook.");
    }

    private static IntPtr SetHook(LowLevelKeyboardProc proc)
    {
        using var currentProcess = Process.GetCurrentProcess();
        using var currentModule = currentProcess.MainModule;
        var moduleHandle = currentModule is null ? IntPtr.Zero : GetModuleHandle(currentModule.ModuleName);
        return SetWindowsHookEx(WhKeyboardLl, proc, moduleHandle, 0);
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0 && (wParam == (IntPtr)WmKeyDown || wParam == (IntPtr)WmSysKeyDown))
        {
            var data = Marshal.PtrToStructure<KbdLlHookStruct>(lParam);
            var vkCode = unchecked((int)data.vkCode);

            if (vkCode == VkF3)
            {
                var now = DateTime.UtcNow;
                if (now - _lastF3At > TimeSpan.FromMilliseconds(450))
                {
                    _lastF3At = now;
                    F3Pressed?.Invoke();
                }

                // F3 belongs to Word Watcher while it is running.
                return (IntPtr)1;
            }

            var controlDown = IsDown(VkControl);
            if (controlDown && vkCode == VkC)
            {
                CopyGesture?.Invoke();
            }
            else if (controlDown && vkCode == VkV)
            {
                PasteGesture?.Invoke();
            }
            else if (vkCode == VkBack)
            {
                BackspacePressed?.Invoke();
            }
            else if (!controlDown && !IsDown(VkMenu) && !IsDown(VkLWin) && !IsDown(VkRWin))
            {
                var character = TranslateKey(data);
                if (character.HasValue && !char.IsControl(character.Value))
                    CharacterTyped?.Invoke(character.Value);
            }
        }

        return CallNextHookEx(_hookId, nCode, wParam, lParam);
    }

    private static bool IsDown(int virtualKey)
        => (GetAsyncKeyState(virtualKey) & 0x8000) != 0;

    private static char? TranslateKey(KbdLlHookStruct data)
    {
        var keyboardState = new byte[256];
        if (!GetKeyboardState(keyboardState)) return null;

        var vkCode = unchecked((int)data.vkCode);
        if (vkCode >= 0 && vkCode < keyboardState.Length)
            keyboardState[vkCode] |= 0x80;

        var buffer = new StringBuilder(8);
        var layout = GetKeyboardLayout(0);
        var result = ToUnicodeEx(
            data.vkCode,
            data.scanCode,
            keyboardState,
            buffer,
            buffer.Capacity,
            0,
            layout);

        if (result > 0 && buffer.Length > 0)
            return buffer[0];

        // Negative means a dead key. Calling again clears the dead-key state.
        if (result < 0)
            ToUnicodeEx(data.vkCode, data.scanCode, keyboardState, buffer, buffer.Capacity, 0, layout);

        return null;
    }

    public void Dispose()
    {
        if (_hookId != IntPtr.Zero)
        {
            UnhookWindowsHookEx(_hookId);
            _hookId = IntPtr.Zero;
        }
    }

    private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct KbdLlHookStruct
    {
        public uint vkCode;
        public uint scanCode;
        public uint flags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string? lpModuleName);

    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int vKey);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetKeyboardState(byte[] lpKeyState);

    [DllImport("user32.dll")]
    private static extern IntPtr GetKeyboardLayout(uint idThread);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int ToUnicodeEx(
        uint wVirtKey,
        uint wScanCode,
        byte[] lpKeyState,
        [Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pwszBuff,
        int cchBuff,
        uint wFlags,
        IntPtr dwhkl);
}
