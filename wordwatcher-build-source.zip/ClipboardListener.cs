using System.Runtime.InteropServices;

namespace WordWatcher;

internal sealed class ClipboardListener : NativeWindow, IDisposable
{
    private const int WmClipboardUpdate = 0x031D;
    private static readonly IntPtr HwndMessage = new(-3);
    private bool _registered;

    public event Action? ClipboardChanged;

    public ClipboardListener()
    {
        CreateHandle(new CreateParams
        {
            Caption = "WordWatcherClipboardListener",
            Parent = HwndMessage
        });

        _registered = AddClipboardFormatListener(Handle);
        if (!_registered)
        {
            DestroyHandle();
            throw new InvalidOperationException("Windows could not start clipboard monitoring.");
        }
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == WmClipboardUpdate)
            ClipboardChanged?.Invoke();

        base.WndProc(ref m);
    }

    public void Dispose()
    {
        if (_registered)
        {
            RemoveClipboardFormatListener(Handle);
            _registered = false;
        }

        if (Handle != IntPtr.Zero)
            DestroyHandle();
    }

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool AddClipboardFormatListener(IntPtr hwnd);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool RemoveClipboardFormatListener(IntPtr hwnd);
}
