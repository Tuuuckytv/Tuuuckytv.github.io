using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;

namespace WordWatcher;

internal sealed class WordWatcherContext : ApplicationContext
{
    private readonly SettingsStore _settingsStore = new();
    private readonly WordWatcherSettings _settings;
    private readonly MainForm _form;
    private readonly NotifyIcon _trayIcon;
    private readonly ToolStripMenuItem _pauseItem;
    private readonly KeyboardHook _keyboardHook;
    private readonly ClipboardListener _clipboardListener;
    private readonly StringBuilder _typedBuffer = new();
    private readonly Dictionary<string, DateTime> _lastAlertAt = new(StringComparer.OrdinalIgnoreCase);

    private DateTime _lastTypedAt = DateTime.MinValue;
    private bool _alertOpen;
    private bool _exiting;

    public WordWatcherContext()
    {
        _settings = _settingsStore.Load();

        _form = new MainForm();
        _form.LoadSettings(_settings, _settingsStore.CurrentPath);
        _form.TermsSaved += SaveTerms;
        _form.MonitoringToggleRequested += ToggleMonitoring;
        _form.ExitRequested += ExitApplication;

        var menu = new ContextMenuStrip();
        var openItem = new ToolStripMenuItem("Open / Edit Watch List", null, (_, _) => ShowEditor());
        _pauseItem = new ToolStripMenuItem();
        _pauseItem.Click += (_, _) => ToggleMonitoring();
        var exitItem = new ToolStripMenuItem("Exit", null, (_, _) => ExitApplication());
        menu.Items.Add(openItem);
        menu.Items.Add(_pauseItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(exitItem);

        _trayIcon = new NotifyIcon
        {
            Icon = SystemIcons.Information,
            Text = "Word Watcher",
            Visible = true,
            ContextMenuStrip = menu
        };
        _trayIcon.DoubleClick += (_, _) => ShowEditor();

        UpdateMonitoringUi();

        try
        {
            _keyboardHook = new KeyboardHook();
            _keyboardHook.F3Pressed += () => _form.BeginInvoke(ShowEditor);
            _keyboardHook.CharacterTyped += character => _form.BeginInvoke(() => OnCharacterTyped(character));
            _keyboardHook.BackspacePressed += () => _form.BeginInvoke(OnBackspace);
            _keyboardHook.PasteGesture += () => _form.BeginInvoke(() => CheckClipboard("Pasted"));

            _clipboardListener = new ClipboardListener();
            _clipboardListener.ClipboardChanged += () => _form.BeginInvoke(() => CheckClipboard("Copied"));
        }
        catch (Exception ex)
        {
            _trayIcon.Visible = false;
            _trayIcon.Dispose();
            _form.CloseForExit();
            MessageBox.Show(
                $"Word Watcher could not start keyboard monitoring.\n\n{ex.Message}",
                "Word Watcher",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            throw;
        }
    }

    private bool DetectionAllowed => _settings.MonitoringEnabled && !_form.Visible && !_alertOpen;

    private IReadOnlyList<string> OrderedTerms => _settings.WatchTerms
        .OrderByDescending(term => term.Length)
        .ToArray();

    private void ShowEditor()
    {
        _typedBuffer.Clear();
        _form.LoadSettings(_settings, _settingsStore.CurrentPath);
        _form.ShowEditor();
    }

    private void SaveTerms(List<string> terms)
    {
        _settings.WatchTerms = SettingsStore.NormaliseTerms(terms);
        PersistSettings();
        _typedBuffer.Clear();
    }

    private void ToggleMonitoring()
    {
        _settings.MonitoringEnabled = !_settings.MonitoringEnabled;
        _typedBuffer.Clear();
        PersistSettings();
        UpdateMonitoringUi();
    }

    private void UpdateMonitoringUi()
    {
        _pauseItem.Text = _settings.MonitoringEnabled ? "Pause Monitoring" : "Resume Monitoring";
        _form.SetMonitoringState(_settings.MonitoringEnabled);
    }

    private void PersistSettings()
    {
        try
        {
            _settingsStore.Save(_settings);
            _form.SetSettingsPath(_settingsStore.CurrentPath);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                $"Word Watcher could not save its local settings.\n\n{ex.Message}",
                "Word Watcher",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }

    private void OnCharacterTyped(char character)
    {
        if (!DetectionAllowed) return;

        var now = DateTime.UtcNow;
        if (now - _lastTypedAt > TimeSpan.FromSeconds(6))
            _typedBuffer.Clear();
        _lastTypedAt = now;

        _typedBuffer.Append(character);
        TrimTypedBuffer();

        var text = _typedBuffer.ToString();
        foreach (var term in OrderedTerms)
        {
            if (text.EndsWith(term, StringComparison.OrdinalIgnoreCase))
            {
                ShowMatch(term, "Typed");
                return;
            }
        }
    }

    private void OnBackspace()
    {
        if (!DetectionAllowed || _typedBuffer.Length == 0) return;
        _typedBuffer.Length--;
    }

    private void TrimTypedBuffer()
    {
        var longest = _settings.WatchTerms.Count == 0 ? 64 : _settings.WatchTerms.Max(term => term.Length);
        var limit = Math.Clamp(longest + 128, 256, 4096);
        if (_typedBuffer.Length <= limit) return;

        _typedBuffer.Remove(0, _typedBuffer.Length - limit);
    }

    private void CheckClipboard(string source)
    {
        if (!DetectionAllowed) return;

        string clipboardText;
        try
        {
            if (!Clipboard.ContainsText()) return;
            clipboardText = Clipboard.GetText(TextDataFormat.UnicodeText);
        }
        catch (ExternalException)
        {
            return;
        }

        if (string.IsNullOrEmpty(clipboardText)) return;

        foreach (var term in OrderedTerms)
        {
            if (clipboardText.IndexOf(term, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                ShowMatch(term, source);
                return;
            }
        }
    }

    private void ShowMatch(string term, string source)
    {
        if (_alertOpen) return;

        var now = DateTime.UtcNow;
        if (_lastAlertAt.TryGetValue(term, out var last) && now - last < TimeSpan.FromSeconds(3))
            return;

        _alertOpen = true;
        _lastAlertAt[term] = now;
        _typedBuffer.Clear();

        try
        {
            MessageBox.Show(
                $"Word found\n\n{term}\n\nDetected from: {source}\n\nPress OK to continue.",
                "Word found",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button1,
                MessageBoxOptions.DefaultDesktopOnly);
        }
        finally
        {
            _lastAlertAt[term] = DateTime.UtcNow;
            _alertOpen = false;
            _typedBuffer.Clear();
        }
    }

    private void ExitApplication()
    {
        if (_exiting) return;
        _exiting = true;

        PersistSettings();
        _clipboardListener.Dispose();
        _keyboardHook.Dispose();
        _trayIcon.Visible = false;
        _trayIcon.Dispose();
        _form.CloseForExit();
        ExitThread();
    }

    protected override void ExitThreadCore()
    {
        if (!_exiting)
        {
            _exiting = true;
            try { _clipboardListener.Dispose(); } catch { }
            try { _keyboardHook.Dispose(); } catch { }
            try { _trayIcon.Visible = false; _trayIcon.Dispose(); } catch { }
            try { _form.CloseForExit(); } catch { }
        }

        base.ExitThreadCore();
    }
}
