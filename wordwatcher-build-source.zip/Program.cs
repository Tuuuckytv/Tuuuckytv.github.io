using System;
using System.Windows.Forms;

namespace WordWatcher;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new WordWatcherContext());
    }
}
