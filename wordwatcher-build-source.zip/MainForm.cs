using System.Drawing;

namespace WordWatcher;

internal sealed class MainForm : Form
{
    private readonly TextBox _termsBox;
    private readonly Button _monitoringButton;
    private readonly Label _statusLabel;
    private readonly Label _settingsLabel;
    private bool _allowClose;

    public event Action<List<string>>? TermsSaved;
    public event Action? MonitoringToggleRequested;
    public event Action? ExitRequested;

    public MainForm()
    {
        Text = "Word Watcher";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(520, 430);
        Size = new Size(620, 520);
        FormBorderStyle = FormBorderStyle.Sizable;
        MaximizeBox = false;
        ShowIcon = true;
        Icon = SystemIcons.Information;
        Font = new Font("Segoe UI", 9F);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 6,
            Padding = new Padding(18)
        };
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        var title = new Label
        {
            AutoSize = true,
            Text = "WORD WATCHER",
            Font = new Font("Segoe UI Semibold", 16F, FontStyle.Bold),
            Margin = new Padding(0, 0, 0, 5)
        };

        var intro = new Label
        {
            AutoSize = true,
            Text = "Press F3 anywhere to open this window. Enter one watched word, phrase or number per line.",
            ForeColor = Color.DimGray,
            Margin = new Padding(0, 0, 0, 12)
        };

        _termsBox = new TextBox
        {
            Dock = DockStyle.Fill,
            Multiline = true,
            AcceptsReturn = true,
            AcceptsTab = false,
            ScrollBars = ScrollBars.Vertical,
            WordWrap = false,
            Font = new Font("Consolas", 11F),
            BorderStyle = BorderStyle.FixedSingle
        };

        var buttonRow = new FlowLayoutPanel
        {
            AutoSize = true,
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            Margin = new Padding(0, 12, 0, 6)
        };

        var saveButton = new Button { AutoSize = true, Text = "Save Watch List", Padding = new Padding(8, 4, 8, 4) };
        saveButton.Click += (_, _) => SaveTerms();

        _monitoringButton = new Button { AutoSize = true, Padding = new Padding(8, 4, 8, 4) };
        _monitoringButton.Click += (_, _) => MonitoringToggleRequested?.Invoke();

        var hideButton = new Button { AutoSize = true, Text = "Hide", Padding = new Padding(8, 4, 8, 4) };
        hideButton.Click += (_, _) => { SaveTerms(); Hide(); };

        var exitButton = new Button { AutoSize = true, Text = "Exit", Padding = new Padding(8, 4, 8, 4) };
        exitButton.Click += (_, _) => ExitRequested?.Invoke();

        buttonRow.Controls.Add(saveButton);
        buttonRow.Controls.Add(_monitoringButton);
        buttonRow.Controls.Add(hideButton);
        buttonRow.Controls.Add(exitButton);

        _statusLabel = new Label
        {
            AutoSize = true,
            Margin = new Padding(0, 5, 0, 2)
        };

        _settingsLabel = new Label
        {
            AutoSize = true,
            ForeColor = Color.DimGray,
            Font = new Font("Segoe UI", 8F),
            Margin = new Padding(0, 3, 0, 0)
        };

        root.Controls.Add(title, 0, 0);
        root.Controls.Add(intro, 0, 1);
        root.Controls.Add(_termsBox, 0, 2);
        root.Controls.Add(buttonRow, 0, 3);
        root.Controls.Add(_statusLabel, 0, 4);
        root.Controls.Add(_settingsLabel, 0, 5);
        Controls.Add(root);

        FormClosing += (_, e) =>
        {
            if (_allowClose) return;
            e.Cancel = true;
            SaveTerms();
            Hide();
        };
    }

    public void LoadSettings(WordWatcherSettings settings, string settingsPath)
    {
        _termsBox.Lines = settings.WatchTerms.ToArray();
        SetMonitoringState(settings.MonitoringEnabled);
        SetSettingsPath(settingsPath);
    }

    public void SetMonitoringState(bool enabled)
    {
        _monitoringButton.Text = enabled ? "Pause Monitoring" : "Resume Monitoring";
        _statusLabel.Text = enabled
            ? "Status: Monitoring is ON. This editor window is excluded from matching while it is open."
            : "Status: Monitoring is PAUSED. F3 still opens Word Watcher.";
        _statusLabel.ForeColor = enabled ? Color.DarkGreen : Color.DarkOrange;
    }

    public void SetSettingsPath(string path)
    {
        _settingsLabel.Text = $"Local settings: {path}";
    }

    public void ShowEditor()
    {
        if (!Visible) Show();
        WindowState = FormWindowState.Normal;
        Activate();
        BringToFront();
        _termsBox.Focus();
    }

    public void CloseForExit()
    {
        _allowClose = true;
        Close();
    }

    private void SaveTerms()
    {
        var terms = SettingsStore.NormaliseTerms(_termsBox.Lines);
        _termsBox.Lines = terms.ToArray();
        TermsSaved?.Invoke(terms);
    }
}
